Basis Data Teori
Silahkan pelajari file "04. Tambahan Materi Basis Data MySQL"


Basis Data Praktikum 
Silahkan dikerjakan Job Sheet Pertemuan 4 